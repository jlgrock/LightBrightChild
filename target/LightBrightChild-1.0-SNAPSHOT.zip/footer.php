		</div> <!-- end #content-area -->
		
		<div id="footer">
			<p id="copyright"><?php esc_html_e('Designed by ','LightBright'); ?> <a href="http://www.elegantthemes.com" title="Elegant Themes">Elegant Themes</a> | <?php esc_html_e('Modifications By ','LightBrightChild'); ?> 
			<script type="text/javascript">
				document.write("<a href='&#109;&#97;&#105;&#108;&#116;&#111;: &#106;&#108;&#103;&#114&#111;&#99;&#107;&#64;&#104;&#111;&#116;&#109;&#97;&#105;&#108;&#46;&#99;&#111;&#109;'>Justin Grant</a>");
			</script> <?php esc_html_e('Powered by ','LightBright'); ?> <a href="http://www.wordpress.org">Wordpress</a></p>
		</div> <!-- end #footer -->
	</div> <!-- end #container -->
	
	<?php get_template_part('includes/scripts'); ?>
	<?php wp_footer(); ?>
	
</body>
</html>